@echo off
setlocal
cd /d "%~dp0"
rem Zapret-Zen portable launcher. Requests elevation via the app itself.
"%~dp0python.exe" -m zapret_zen.main %*
exit /b %errorlevel%
