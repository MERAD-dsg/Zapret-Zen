@echo off
setlocal
cd /d "%~dp0"
rem Zapret-Zen portable launcher. The app requests elevation itself.
"%~dp0pythonw.exe" -m zapret_zen.main %*
exit /b %errorlevel%
