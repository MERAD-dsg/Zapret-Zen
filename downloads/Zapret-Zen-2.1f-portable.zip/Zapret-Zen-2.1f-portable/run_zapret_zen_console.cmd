@echo off
setlocal
cd /d "%~dp0"
echo ==== Zapret-Zen portable (console) ====
"%~dp0python.exe" -c "import sys; print(sys.version)"
"%~dp0python.exe" -c "import PySide6, zapret_zen; print('PySide6', PySide6.__version__, 'Zapret-Zen', zapret_zen.__version__)"
"%~dp0python.exe" -m zapret_zen.main
echo ==== exit code: %errorlevel% ====
pause
